package com.dotronglong.faker.pojo

data class Names(
        val region: String,
        val male: List<String>,
        val female: List<String>,
        val surname: List<String>
)